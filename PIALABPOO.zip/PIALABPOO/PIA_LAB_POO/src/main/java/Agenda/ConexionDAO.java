/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Agenda;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author melin
 */
public class ConexionDAO {
    private static final String url="jdbc:mysql://localhost:3306/dbusur";
    private static final String username="root";
    private static final String pass="root";
    
    public static Connection obtenerConexion(){
        Connection conn = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url,username,pass);
        }
        catch(Exception e){
            System.out.println("Error al conectarnos: " + e.toString());
        }
        return conn;
    }
    public static void cerrarConexion(Connection conn){
        try{
            if(conn != null){
                conn.close();
            }
        }
        catch(Exception e){
            System.out.println("Error al conectarnos: " + e.toString());
        }
    }
    public static boolean probarConexion() {
        Connection conn = null;
        try {
            conn = obtenerConexion();
            return conn != null && !conn.isClosed();
        } catch (Exception e) {
            return false;
        } finally {
            cerrarConexion(conn);
        }
}

}
