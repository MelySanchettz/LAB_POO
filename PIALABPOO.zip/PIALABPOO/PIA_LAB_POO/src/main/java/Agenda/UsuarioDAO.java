/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Agenda;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author melin
 */
public class UsuarioDAO {
    public void insertarUsuario(String nombre, String appaterno, String apmaterno, int edad, String sexo,String telefono,String direccion,String tipoContacto){
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try{
            conn = ConexionDAO.obtenerConexion();
            String sql = "insert into usuarios(nombres,appaterno,apmaterno,edad,sexo,telefono,direccion,tipoContacto) values (?,?,?,?,?,?,?,?);";
            stmt = conn.prepareCall(sql);
            
            stmt.setString(1, nombre);
            stmt.setString(2, appaterno);
            stmt.setString(3, apmaterno);
            stmt.setInt(4, edad);
            stmt.setString(5, sexo);
            stmt.setString(6, telefono);
            stmt.setString(7, direccion);
            stmt.setString(8, tipoContacto);
            
            stmt.executeUpdate();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            ConexionDAO.cerrarConexion(conn);
            try{
                if(stmt != null)stmt.close();
            }
            catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
    
    public List<EntidadUsuario> obtenenerUsuarios(){
        List<EntidadUsuario> usuarios = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs=null;
        
        try{
            conn = ConexionDAO.obtenerConexion();
            String sql = "select * from usuarios;";
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while(rs.next()){
                EntidadUsuario usuario = new EntidadUsuario();
                usuario.setId(rs.getInt("id"));
                usuario.setNombres(rs.getString("nombres"));
                usuario.setAppaterno(rs.getString("appaterno"));
                usuario.setApmaterno(rs.getString("apmaterno"));
                usuario.setEdad(rs.getInt("edad"));
                usuario.setSexo(rs.getString("sexo"));
                usuario.setTelefono(rs.getString("telefono"));
                usuario.setDireccion(rs.getString("direccion"));
                usuario.setTipoContacto(rs.getString("tipoContacto"));
                usuarios.add(usuario);
                
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            ConexionDAO.cerrarConexion(conn);
            try{
                if(stmt != null)stmt.close();
            }
            catch(SQLException ex){
                ex.printStackTrace();
            }
            try{
                if(rs != null)rs.close();
            }
            catch(SQLException ex){
                ex.printStackTrace();
            }
        }
        return usuarios;
        
    }
    public void eliminarUsuario(int id){
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try{
            conn = ConexionDAO.obtenerConexion();
            String sql = "delete from usuarios where id = ?;";
            stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);
            
            stmt.executeUpdate();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            ConexionDAO.cerrarConexion(conn);
            try{
                if(stmt != null)stmt.close();
            }
            catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
    public void modificarUsuario(String nombre, String appaterno, String apmaterno, int edad, String sexo,String telefono,String direccion,String tipoContacto, int id){
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try{
            conn = ConexionDAO.obtenerConexion();
            String sql = "update usuarios set nombres = ?, appaterno = ?, apmaterno = ?, edad = ?, sexo = ?, telefono = ?, direccion = ?, tipoContacto = ? where id = ?";
            stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, nombre);
            stmt.setString(2, appaterno);
            stmt.setString(3, apmaterno);
            stmt.setInt(4, edad);
            stmt.setString(5, sexo);
            stmt.setString(6, telefono);
            stmt.setString(7, direccion);
            stmt.setString(8, tipoContacto);
            stmt.setInt(9, id);
            
            stmt.executeUpdate();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            ConexionDAO.cerrarConexion(conn);
            try{
                if(stmt != null)stmt.close();
            }
            catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
    
    
}
