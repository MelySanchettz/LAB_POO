/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Agenda;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author melin
 */
@WebServlet(name = "servletusuario", urlPatterns = {"/servletusuario"})
public class servletusuario extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {      
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        if("mostrar".equals(action)){
            mostrarUsuarios(request, response);
        }
        else if("guardar".equals(action)){
            mostrarUsuariosGuardar(request, response);
        }
        else if("modificar".equals(action)){
            mostrarUsuariosModificar(request, response);
        }
        else if("eliminar".equals(action)){
            mostrarUsuariosEliminar(request, response);
        }
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if("guardar".equals(action)){
            guardarUsuarios(request, response);
        }
        else if("modificar".equals(action)){
            modificarUsuarios(request, response);
        }
        else if("eliminar".equals(action)){
            eliminarUsuarios(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    public void guardarUsuarios(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String nombres = request.getParameter("nombres");
        String appaterno = request.getParameter("appaterno");
        String apmaterno = request.getParameter("apmaterno");
        String edadStr = request.getParameter("edad");
        String sexo = request.getParameter("sexo");
        String telefono = request.getParameter("telefono");
        String direccion = request.getParameter("direccion");
        String tipoContacto = request.getParameter("tipoContacto");

        // ====== VALIDACIONES ======

        // Validación de campos vacíos
        if (nombres == null || nombres.trim().isEmpty()) {
            request.setAttribute("error", "El nombre no puede estar vacío.");
            mostrarUsuariosGuardar(request, response);
            return;
        }
        if (appaterno == null || appaterno.trim().isEmpty()) {
            request.setAttribute("error", "El apellido paterno no puede estar vacío.");
            mostrarUsuariosGuardar(request, response);
            return;
        }
        if (apmaterno == null || apmaterno.trim().isEmpty()) {
            request.setAttribute("error", "El apellido materno no puede estar vacío.");
            mostrarUsuariosGuardar(request, response);
            return;
        }

        // Validación de edad numérica
        int edad = 0;
        try {
            edad = Integer.parseInt(edadStr);
            if (edad <= 0 || edad > 120) {
                request.setAttribute("error", "La edad debe ser un número entre 1 y 120.");
                mostrarUsuariosGuardar(request, response);
                return;
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "La edad debe ser un número válido.");
            mostrarUsuariosGuardar(request, response);
            return;
        }

        // Validación teléfono
        // Validación teléfono
        if (telefono == null || telefono.trim().isEmpty()) {
            request.setAttribute("error", "El teléfono no puede estar vacío.");
            mostrarUsuariosGuardar(request, response);
            return;
        }

        // Solo números
        if (!telefono.matches("\\d+")) {
            request.setAttribute("error", "El teléfono solo puede contener números.");
            mostrarUsuariosGuardar(request, response);
            return;
        }

        // Longitud de 7 a 15 dígitos
        if (telefono.length() < 7 || telefono.length() > 15) {
            request.setAttribute("error", "El teléfono debe tener entre 7 y 15 dígitos.");
            mostrarUsuariosGuardar(request, response);
            return;
        }


        // Validación dirección
        if (direccion == null || direccion.trim().isEmpty()) {
            request.setAttribute("error", "La dirección no puede estar vacía.");
            mostrarUsuariosGuardar(request, response);
            return;
        }

        // ====== SI TODO ES VÁLIDO, GUARDAR ======

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        usuarioDAO.insertarUsuario(nombres, appaterno, apmaterno, edad, sexo, telefono, direccion, tipoContacto);

        mostrarUsuariosGuardar(request, response);
    }

    
    public void mostrarUsuarios(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        List<EntidadUsuario> usuarios = usuarioDAO.obtenenerUsuarios();
        request.setAttribute("listausuarios", usuarios);
        
        request.getRequestDispatcher("mostrarUsuarios.jsp").forward(request, response);
    }
    
    
    
    public void mostrarUsuariosGuardar(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        List<EntidadUsuario> usuarios = usuarioDAO.obtenenerUsuarios();
        request.setAttribute("listausuarios", usuarios);
        
        request.getRequestDispatcher("guardarUsuarios.jsp").forward(request, response);
    }
    
    public void modificarUsuarios(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {

        String idStr = request.getParameter("id");

        // Validación: si no seleccionaron un usuario
        if (idStr == null || idStr.trim().isEmpty()) {
            request.setAttribute("error", "Debe seleccionar un usuario de la tabla antes de modificar.");
            mostrarUsuariosModificar(request, response);
            return;
        }

        int id = Integer.parseInt(idStr); 

        String nombres = request.getParameter("nombres");
        String appaterno = request.getParameter("appaterno");
        String apmaterno = request.getParameter("apmaterno");
        String edadStr = request.getParameter("edad");
        String sexo = request.getParameter("sexo");
        String telefono = request.getParameter("telefono");
        String direccion = request.getParameter("direccion");
        String tipoContacto = request.getParameter("tipoContacto");

        // ====== VALIDACIONES ======

        if (nombres == null || nombres.trim().isEmpty()) {
            request.setAttribute("error", "El nombre no puede estar vacío.");
            mostrarUsuariosModificar(request, response);
            return;
        }
        if (appaterno == null || appaterno.trim().isEmpty()) {
            request.setAttribute("error", "El apellido paterno no puede estar vacío.");
            mostrarUsuariosModificar(request, response);
            return;
        }
        if (apmaterno == null || apmaterno.trim().isEmpty()) {
            request.setAttribute("error", "El apellido materno no puede estar vacío.");
            mostrarUsuariosModificar(request, response);
            return;
        }

        int edad = 0;
        try {
            edad = Integer.parseInt(edadStr);
            if (edad <= 0 || edad > 120) {
                request.setAttribute("error", "La edad debe ser un número entre 1 y 120.");
                mostrarUsuariosModificar(request, response);
                return;
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "La edad debe ser un número válido.");
            mostrarUsuariosModificar(request, response);
            return;
        }

        // Validación teléfono
        if (telefono == null || telefono.trim().isEmpty()) {
            request.setAttribute("error", "El teléfono no puede estar vacío.");
            mostrarUsuariosModificar(request, response);
            return;
        }

        // Solo números
        if (!telefono.matches("\\d+")) {
            request.setAttribute("error", "El teléfono solo puede contener números.");
            mostrarUsuariosModificar(request, response);
            return;
        }

        // Longitud de 7 a 15 dígitos
        if (telefono.length() < 7 || telefono.length() > 15) {
            request.setAttribute("error", "El teléfono debe tener entre 7 y 15 dígitos.");
            mostrarUsuariosModificar(request, response);
            return;
        }


        if (direccion == null || direccion.trim().isEmpty()) {
            request.setAttribute("error", "La dirección no puede estar vacía.");
            mostrarUsuariosModificar(request, response);
            return;
        }

        // ====== SI TODO ES VÁLIDO, MODIFICAR ======

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        usuarioDAO.modificarUsuario(nombres, appaterno, apmaterno, edad, sexo, telefono, direccion, tipoContacto, id);

        mostrarUsuariosModificar(request, response);
    }

    
    public void eliminarUsuarios(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String idStr = request.getParameter("id");

        // Validación: si no se seleccionó un usuario
        if (idStr == null || idStr.trim().isEmpty()) {
            request.setAttribute("error", "Debe seleccionar un usuario de la tabla antes de eliminar.");
            mostrarUsuariosEliminar(request, response);
            return;
        }

        int id = Integer.parseInt(idStr);

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        usuarioDAO.eliminarUsuario(id);

        mostrarUsuariosEliminar(request, response);
    }

    
    public void mostrarUsuariosModificar(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        List<EntidadUsuario> usuarios = usuarioDAO.obtenenerUsuarios();
        request.setAttribute("listausuarios", usuarios);
        
        request.getRequestDispatcher("modificarUsuarios.jsp").forward(request, response);
    }
    
    public void mostrarUsuariosEliminar(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        List<EntidadUsuario> usuarios = usuarioDAO.obtenenerUsuarios();
        request.setAttribute("listausuarios", usuarios);
        
        request.getRequestDispatcher("eliminarUsuarios.jsp").forward(request, response);
    }
}
