create database dbusur;
use dbusur;

create table usuarios(
	id int auto_increment not null primary key,
    nombres varchar(50),
    appaterno varchar(50),
    apmaterno varchar(50),
    edad int
);