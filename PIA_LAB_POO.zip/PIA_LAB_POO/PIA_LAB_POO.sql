CREATE TABLE contacto (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50),
  apellidoPaterno VARCHAR(50),
  apellidoMaterno VARCHAR(50),
  sexo ENUM('M','F','O'),
  telefono VARCHAR(20),
  direccion VARCHAR(100),
  tipoContacto ENUM('CASA','TRABAJO')
);
