package agenda;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ContactoServlet extends HttpServlet {

    private ContactoDAO dao = new ContactoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("lista", dao.listar());
        RequestDispatcher rd = request.getRequestDispatcher("views/lista.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Contacto c = new Contacto();
        c.setNombre(request.getParameter("nombre"));
        c.setApellidoPaterno(request.getParameter("apellidoPaterno"));
        c.setApellidoMaterno(request.getParameter("apellidoMaterno"));
        c.setSexo(request.getParameter("sexo"));
        c.setTelefono(request.getParameter("telefono"));
        c.setDireccion(request.getParameter("direccion"));
        c.setTipoContacto(request.getParameter("tipoContacto"));

        dao.insertar(c);
        response.sendRedirect("ContactoServlet");
    }
}
