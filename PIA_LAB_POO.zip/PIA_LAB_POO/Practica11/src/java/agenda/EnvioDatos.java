package agenda;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EnvioDatos extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<meta charset='UTF-8'>");
            out.println("<title>Prueba de conexión</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; text-align: center; margin-top: 50px; }");
            out.println("button { padding: 10px 20px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }");
            out.println("button:hover { background-color: #0056b3; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");

            out.println("<h2>Prueba de conexión con MySQL</h2>");
            Connection conn = DB.getConnection();
            if (conn != null) {
                out.println("<p style='color:green;'>✅ Conexión exitosa.</p>");
            } else {
                out.println("<p style='color:red;'>❌ No se pudo conectar.</p>");
            }

            // Botón de regreso
            out.println("<br><br>");
            out.println("<form action='Index.jsp' method='get'>");
            out.println("<button type='submit'>⬅ Regresar</button>");
            out.println("</form>");

            out.println("</body>");
            out.println("</html>");
        }
    }
}
